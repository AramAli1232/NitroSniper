You have to turn off antivirus windows might say this .exe is harmful but it is proven to be not



DO NOT LEAK THIS SNIPER